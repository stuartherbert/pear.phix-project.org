<?php

namespace Phix_Project\Autoloader4;

trait Trait1
{

}