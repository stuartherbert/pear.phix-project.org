# phix-cli

This is the generic CLI tool used to build commands such as phix