<?php

namespace Phix_Project\Autoloader4;

class Dummy1
{

}