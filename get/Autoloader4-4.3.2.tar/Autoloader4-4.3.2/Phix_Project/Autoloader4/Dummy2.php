<?php

namespace Phix_Project\Autoloader4;

class Dummy2
{
        use Trait1;
}