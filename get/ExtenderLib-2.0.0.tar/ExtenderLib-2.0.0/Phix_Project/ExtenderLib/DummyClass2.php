<?php

namespace Phix_Project\ExtenderLib;

$testVar = 'trout';

class DummyClass2
{
        
}
