<?php

namespace Phix_Project\ExtenderLib;

class DummyClass1
{
        
}
